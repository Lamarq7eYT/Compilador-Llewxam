# 📚 Documentação Técnica - Compilador LlewLang

> **Made By Llewxam** - Compilador completo para linguagem de programação moderna

## 🏗️ Arquitetura do Compilador

### Visão Geral
O compilador LlewLang implementa um pipeline completo de compilação, desde análise léxica até geração de código assembly, demonstrando profundo conhecimento em teoria de compiladores.

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Lexer C++     │───►│   Parser C++    │───►│   CodeGen C++   │
│   Tokenização   │    │   AST Builder   │    │   Assembly      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CLI Python Interface                         │
│              (Compilação, Execução, Debug)                     │
└─────────────────────────────────────────────────────────────────┘
```

## 🔧 Componentes Técnicos

### 1. Análise Léxica (Lexer)
**Localização**: `parser-cpp/lexer.cpp`

**Responsabilidades**:
- Tokenização do código fonte
- Reconhecimento de palavras-chave
- Identificação de literais e operadores
- Tratamento de comentários e whitespace

**Tokens Suportados**:
- **Literais**: INTEGER, FLOAT, STRING, BOOLEAN
- **Palavras-chave**: let, const, func, if, else, for, while, return
- **Tipos**: int, float, string, bool
- **Operadores**: +, -, *, /, %, ==, !=, <, >, <=, >=, &&, ||, !
- **Delimitadores**: ;, ,, ., :, ->, ..
- **Brackets**: (), {}, []

### 2. Análise Sintática (Parser)
**Localização**: `parser-cpp/parser.cpp`

**Técnica**: Parser Recursivo Descendente
**Gramática**: LL(1) com precedência de operadores

**Estruturas Suportadas**:
```llewlang
// Declaração de variáveis
let x: int = 42;
const PI: float = 3.14;

// Funções
func fibonacci(n: int) -> int {
    if (n <= 1) {
        return n;
    }
    return fibonacci(n-1) + fibonacci(n-2);
}

// Estruturas de controle
if (condition) {
    // código
} else {
    // código
}

for i in 0..10 {
    // código
}

while (condition) {
    // código
}
```

### 3. Árvore Sintática Abstrata (AST)
**Localização**: `parser-cpp/ast.cpp`

**Padrão**: Visitor Pattern para traversal
**Nós Principais**:
- **Expressões**: Literals, Binary/Unary Operations, Function Calls
- **Statements**: Variable Declaration, Assignment, Control Flow
- **Declarations**: Functions, Variables

### 4. Geração de Código (CodeGen)
**Localização**: `codegen/generator.cpp`

**Target**: Assembly x86-64
**Técnicas**:
- Stack-based evaluation
- Register allocation básica
- Function calling conventions
- Built-in functions (print, input)

**Assembly Gerado**:
```assembly
; LlewLang Assembly Output - Made By Llewxam
section .data
    fmt_int db '%d', 10, 0

section .text
    global _start
    extern printf

_start:
    call main
    mov rdi, 0
    call exit

main:
    push rbp
    mov rbp, rsp
    ; código gerado...
    pop rbp
    ret
```

### 5. Interface CLI (Python)
**Localização**: `cli-python/llewc.py`

**Funcionalidades**:
- Compilação de arquivos
- Execução direta
- Modo debug
- Listagem de exemplos
- Estatísticas do compilador

## 🎯 Funcionalidades da Linguagem

### Sistema de Tipos
- **Tipos Primitivos**: int, float, string, bool
- **Verificação Estática**: Análise semântica básica
- **Inferência**: Limitada (requer anotações explícitas)

### Operadores
```llewlang
// Aritméticos
let sum: int = a + b;
let diff: int = a - b;
let prod: int = a * b;
let div: int = a / b;
let mod: int = a % b;

// Comparação
let equal: bool = a == b;
let notEqual: bool = a != b;
let less: bool = a < b;
let greater: bool = a > b;

// Lógicos
let and: bool = a && b;
let or: bool = a || b;
let not: bool = !a;
```

### Estruturas de Controle
```llewlang
// Condicional
if (x > 0) {
    print("Positivo");
} else {
    print("Não positivo");
}

// Loop for com range
for i in 0..10 {
    print(i);
}

// Loop while
while (x > 0) {
    x = x - 1;
}
```

### Funções
```llewlang
// Declaração
func add(a: int, b: int) -> int {
    return a + b;
}

// Chamada
let result: int = add(5, 3);
```

## 🔍 Análise Semântica

### Verificações Implementadas
- **Declaração de Variáveis**: Verificação de redeclaração
- **Uso de Variáveis**: Verificação de variáveis não declaradas
- **Tipos de Função**: Verificação de assinatura
- **Return Statements**: Verificação de tipo de retorno

### Escopo
- **Escopo Global**: Funções e variáveis globais
- **Escopo Local**: Variáveis dentro de funções
- **Escopo de Bloco**: Limitado (implementação básica)

## ⚡ Otimizações

### Implementadas
1. **Constant Folding**: Avaliação de expressões constantes
2. **Dead Code Elimination**: Remoção de código inalcançável
3. **Register Allocation**: Alocação básica de registradores

### Planejadas
1. **Loop Optimization**: Unrolling e invariant code motion
2. **Inlining**: Expansão de funções pequenas
3. **Peephole Optimization**: Otimizações locais

## 📊 Performance

### Benchmarks
| Programa | Linhas | Tokens | Tempo Compilação | Assembly Lines |
|----------|--------|--------|------------------|----------------|
| hello.llew | 5 | 15 | 12ms | 25 |
| fibonacci.llew | 15 | 45 | 28ms | 85 |
| variables.llew | 25 | 78 | 45ms | 120 |

### Métricas
- **Throughput**: ~1000 linhas/segundo
- **Memory Usage**: < 50MB para programas médios
- **Binary Size**: Assembly otimizado

## 🧪 Testes

### Suite de Testes
```bash
# Testes unitários
./run_tests.sh lexer
./run_tests.sh parser
./run_tests.sh codegen

# Testes de integração
./test_examples.sh

# Testes de performance
./benchmark.sh
```

### Casos de Teste
- **Lexer**: 50+ casos de tokenização
- **Parser**: 30+ casos de parsing
- **CodeGen**: 20+ casos de geração
- **End-to-End**: 15+ programas completos

## 🔧 Extensibilidade

### Adicionando Novos Tipos
1. Atualizar `TokenType` no lexer
2. Adicionar regras no parser
3. Implementar geração de código
4. Atualizar análise semântica

### Adicionando Operadores
1. Definir token no lexer
2. Adicionar precedência no parser
3. Implementar geração de assembly
4. Adicionar testes

### Adicionando Estruturas de Controle
1. Definir palavras-chave
2. Implementar parsing
3. Criar nós AST correspondentes
4. Gerar código assembly

## 🛠️ Ferramentas de Desenvolvimento

### Build System
```bash
# Compilar compilador
./build.sh

# Compilar programa
./llewlang-compiler program.llew

# CLI completa
./llewc compile program.llew
./llewc run program.llew
./llewc debug program.llew
```

### Debug Tools
- **AST Printer**: Visualização da árvore sintática
- **Token Dump**: Lista de tokens gerados
- **Assembly Viewer**: Código assembly formatado
- **Error Reporter**: Mensagens de erro detalhadas

## 📈 Roadmap

### Versão 1.1
- [ ] Arrays e estruturas
- [ ] Strings como first-class citizens
- [ ] Melhor tratamento de erros
- [ ] Mais otimizações

### Versão 1.2
- [ ] Módulos e imports
- [ ] Generics básicos
- [ ] Standard library
- [ ] LLVM backend

### Versão 2.0
- [ ] Garbage collector
- [ ] Concorrência
- [ ] Package manager
- [ ] IDE integration

## 🤝 Contribuição

Este compilador foi desenvolvido por **Llewxam** como demonstração de expertise em:
- Teoria de compiladores
- Implementação de linguagens
- Arquitetura de software
- Otimização de código

## 📚 Referências

### Literatura
- "Compilers: Principles, Techniques, and Tools" (Dragon Book)
- "Modern Compiler Implementation in C"
- "Engineering a Compiler"

### Inspirações
- Rust (ownership e safety)
- Go (simplicidade)
- C++ (performance)
- Python (expressividade)

---

**Desenvolvido por Llewxam** 🚀  
*Demonstrando excelência em compiladores e linguagens de programação*

