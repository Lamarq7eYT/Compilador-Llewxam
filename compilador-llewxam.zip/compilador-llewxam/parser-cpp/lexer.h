#ifndef LEXER_H
#define LEXER_H

#include <string>
#include <vector>
#include <unordered_map>

// Made By Llewxam - LlewLang Lexer

enum class TokenType {
    // Literals
    INTEGER,
    FLOAT,
    STRING,
    BOOLEAN,
    IDENTIFIER,
    
    // Keywords
    LET,
    CONST,
    FUNC,
    IF,
    ELSE,
    FOR,
    WHILE,
    RETURN,
    STRUCT,
    IN,
    TRUE,
    FALSE,
    
    // Types
    INT_TYPE,
    FLOAT_TYPE,
    STRING_TYPE,
    BOOL_TYPE,
    
    // Operators
    PLUS,
    MINUS,
    MULTIPLY,
    DIVIDE,
    MODULO,
    ASSIGN,
    EQUAL,
    NOT_EQUAL,
    LESS_THAN,
    GREATER_THAN,
    LESS_EQUAL,
    GREATER_EQUAL,
    AND,
    OR,
    NOT,
    
    // Delimiters
    SEMICOLON,
    COMMA,
    DOT,
    COLON,
    ARROW,
    RANGE,
    
    // Brackets
    LEFT_PAREN,
    RIGHT_PAREN,
    LEFT_BRACE,
    RIGHT_BRACE,
    LEFT_BRACKET,
    RIGHT_BRACKET,
    
    // Special
    NEWLINE,
    EOF_TOKEN,
    INVALID
};

struct Token {
    TokenType type;
    std::string value;
    int line;
    int column;
    
    Token(TokenType t, const std::string& v, int l, int c)
        : type(t), value(v), line(l), column(c) {}
};

class Lexer {
private:
    std::string source;
    size_t position;
    size_t line;
    size_t column;
    std::unordered_map<std::string, TokenType> keywords;
    
    void initKeywords();
    char currentChar();
    char peekChar();
    void advance();
    void skipWhitespace();
    void skipComment();
    Token readString();
    Token readNumber();
    Token readIdentifier();
    
public:
    Lexer(const std::string& source);
    std::vector<Token> tokenize();
    Token nextToken();
    std::string tokenTypeToString(TokenType type);
};

#endif // LEXER_H

