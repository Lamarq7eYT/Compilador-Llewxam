#include "ast.h"
#include <sstream>

// Made By Llewxam - LlewLang AST Implementation

// IntegerLiteral
void IntegerLiteral::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string IntegerLiteral::toString() const {
    return std::to_string(value);
}

// FloatLiteral
void FloatLiteral::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string FloatLiteral::toString() const {
    return std::to_string(value);
}

// StringLiteral
void StringLiteral::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string StringLiteral::toString() const {
    return "\"" + value + "\"";
}

// BooleanLiteral
void BooleanLiteral::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string BooleanLiteral::toString() const {
    return value ? "true" : "false";
}

// Identifier
void Identifier::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string Identifier::toString() const {
    return name;
}

// BinaryOperation
void BinaryOperation::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string BinaryOperation::toString() const {
    std::string op;
    switch (operator_) {
        case TokenType::PLUS: op = "+"; break;
        case TokenType::MINUS: op = "-"; break;
        case TokenType::MULTIPLY: op = "*"; break;
        case TokenType::DIVIDE: op = "/"; break;
        case TokenType::MODULO: op = "%"; break;
        case TokenType::EQUAL: op = "=="; break;
        case TokenType::NOT_EQUAL: op = "!="; break;
        case TokenType::LESS_THAN: op = "<"; break;
        case TokenType::GREATER_THAN: op = ">"; break;
        case TokenType::LESS_EQUAL: op = "<="; break;
        case TokenType::GREATER_EQUAL: op = ">="; break;
        case TokenType::AND: op = "&&"; break;
        case TokenType::OR: op = "||"; break;
        default: op = "?"; break;
    }
    return "(" + left->toString() + " " + op + " " + right->toString() + ")";
}

// UnaryOperation
void UnaryOperation::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string UnaryOperation::toString() const {
    std::string op;
    switch (operator_) {
        case TokenType::MINUS: op = "-"; break;
        case TokenType::NOT: op = "!"; break;
        default: op = "?"; break;
    }
    return op + operand->toString();
}

// FunctionCall
void FunctionCall::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string FunctionCall::toString() const {
    std::stringstream ss;
    ss << name << "(";
    for (size_t i = 0; i < arguments.size(); ++i) {
        if (i > 0) ss << ", ";
        ss << arguments[i]->toString();
    }
    ss << ")";
    return ss.str();
}

// ArrayAccess
void ArrayAccess::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string ArrayAccess::toString() const {
    return array->toString() + "[" + index->toString() + "]";
}

// VariableDeclaration
void VariableDeclaration::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string VariableDeclaration::toString() const {
    std::string result = (isConstant ? "const " : "let ") + name + ": " + type;
    if (initializer) {
        result += " = " + initializer->toString();
    }
    return result + ";";
}

// Assignment
void Assignment::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string Assignment::toString() const {
    return name + " = " + value->toString() + ";";
}

// FunctionDeclaration
void FunctionDeclaration::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string FunctionDeclaration::toString() const {
    std::stringstream ss;
    ss << "func " << name << "(";
    
    for (size_t i = 0; i < parameters.size(); ++i) {
        if (i > 0) ss << ", ";
        ss << parameters[i].name << ": " << parameters[i].type;
    }
    
    ss << ") -> " << returnType << " {\n";
    
    for (const auto& stmt : body) {
        ss << "    " << stmt->toString() << "\n";
    }
    
    ss << "}";
    return ss.str();
}

// IfStatement
void IfStatement::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string IfStatement::toString() const {
    std::stringstream ss;
    ss << "if (" << condition->toString() << ") {\n";
    
    for (const auto& stmt : thenBranch) {
        ss << "    " << stmt->toString() << "\n";
    }
    
    ss << "}";
    
    if (!elseBranch.empty()) {
        ss << " else {\n";
        for (const auto& stmt : elseBranch) {
            ss << "    " << stmt->toString() << "\n";
        }
        ss << "}";
    }
    
    return ss.str();
}

// WhileLoop
void WhileLoop::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string WhileLoop::toString() const {
    std::stringstream ss;
    ss << "while (" << condition->toString() << ") {\n";
    
    for (const auto& stmt : body) {
        ss << "    " << stmt->toString() << "\n";
    }
    
    ss << "}";
    return ss.str();
}

// ForLoop
void ForLoop::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string ForLoop::toString() const {
    std::stringstream ss;
    ss << "for " << variable << " in " << start->toString() << ".." << end->toString() << " {\n";
    
    for (const auto& stmt : body) {
        ss << "    " << stmt->toString() << "\n";
    }
    
    ss << "}";
    return ss.str();
}

// ReturnStatement
void ReturnStatement::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string ReturnStatement::toString() const {
    if (value) {
        return "return " + value->toString() + ";";
    }
    return "return;";
}

// ExpressionStatement
void ExpressionStatement::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string ExpressionStatement::toString() const {
    return expression->toString() + ";";
}

// Program
void Program::accept(ASTVisitor& visitor) {
    visitor.visit(*this);
}

std::string Program::toString() const {
    std::stringstream ss;
    ss << "// LlewLang Program - Made By Llewxam\n\n";
    
    for (const auto& stmt : statements) {
        ss << stmt->toString() << "\n\n";
    }
    
    return ss.str();
}

