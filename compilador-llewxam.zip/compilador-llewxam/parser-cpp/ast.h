#ifndef AST_H
#define AST_H

#include <memory>
#include <vector>
#include <string>
#include "lexer.h"

// Made By Llewxam - LlewLang Abstract Syntax Tree

// Forward declarations
class ASTVisitor;

// Base AST Node
class ASTNode {
public:
    virtual ~ASTNode() = default;
    virtual void accept(ASTVisitor& visitor) = 0;
    virtual std::string toString() const = 0;
};

// Expression nodes
class Expression : public ASTNode {
public:
    virtual ~Expression() = default;
};

class Statement : public ASTNode {
public:
    virtual ~Statement() = default;
};

// Literals
class IntegerLiteral : public Expression {
public:
    int value;
    
    IntegerLiteral(int val) : value(val) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

class FloatLiteral : public Expression {
public:
    double value;
    
    FloatLiteral(double val) : value(val) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

class StringLiteral : public Expression {
public:
    std::string value;
    
    StringLiteral(const std::string& val) : value(val) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

class BooleanLiteral : public Expression {
public:
    bool value;
    
    BooleanLiteral(bool val) : value(val) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

class Identifier : public Expression {
public:
    std::string name;
    
    Identifier(const std::string& n) : name(n) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Binary operations
class BinaryOperation : public Expression {
public:
    std::unique_ptr<Expression> left;
    TokenType operator_;
    std::unique_ptr<Expression> right;
    
    BinaryOperation(std::unique_ptr<Expression> l, TokenType op, std::unique_ptr<Expression> r)
        : left(std::move(l)), operator_(op), right(std::move(r)) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Unary operations
class UnaryOperation : public Expression {
public:
    TokenType operator_;
    std::unique_ptr<Expression> operand;
    
    UnaryOperation(TokenType op, std::unique_ptr<Expression> expr)
        : operator_(op), operand(std::move(expr)) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Function call
class FunctionCall : public Expression {
public:
    std::string name;
    std::vector<std::unique_ptr<Expression>> arguments;
    
    FunctionCall(const std::string& n) : name(n) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Array access
class ArrayAccess : public Expression {
public:
    std::unique_ptr<Expression> array;
    std::unique_ptr<Expression> index;
    
    ArrayAccess(std::unique_ptr<Expression> arr, std::unique_ptr<Expression> idx)
        : array(std::move(arr)), index(std::move(idx)) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Variable declaration
class VariableDeclaration : public Statement {
public:
    std::string name;
    std::string type;
    std::unique_ptr<Expression> initializer;
    bool isConstant;
    
    VariableDeclaration(const std::string& n, const std::string& t, bool isConst = false)
        : name(n), type(t), isConstant(isConst) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Assignment
class Assignment : public Statement {
public:
    std::string name;
    std::unique_ptr<Expression> value;
    
    Assignment(const std::string& n, std::unique_ptr<Expression> val)
        : name(n), value(std::move(val)) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Function parameter
struct Parameter {
    std::string name;
    std::string type;
    
    Parameter(const std::string& n, const std::string& t) : name(n), type(t) {}
};

// Function declaration
class FunctionDeclaration : public Statement {
public:
    std::string name;
    std::vector<Parameter> parameters;
    std::string returnType;
    std::vector<std::unique_ptr<Statement>> body;
    
    FunctionDeclaration(const std::string& n, const std::string& retType)
        : name(n), returnType(retType) {}
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// If statement
class IfStatement : public Statement {
public:
    std::unique_ptr<Expression> condition;
    std::vector<std::unique_ptr<Statement>> thenBranch;
    std::vector<std::unique_ptr<Statement>> elseBranch;
    
    IfStatement(std::unique_ptr<Expression> cond) : condition(std::move(cond)) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// While loop
class WhileLoop : public Statement {
public:
    std::unique_ptr<Expression> condition;
    std::vector<std::unique_ptr<Statement>> body;
    
    WhileLoop(std::unique_ptr<Expression> cond) : condition(std::move(cond)) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// For loop
class ForLoop : public Statement {
public:
    std::string variable;
    std::unique_ptr<Expression> start;
    std::unique_ptr<Expression> end;
    std::vector<std::unique_ptr<Statement>> body;
    
    ForLoop(const std::string& var) : variable(var) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Return statement
class ReturnStatement : public Statement {
public:
    std::unique_ptr<Expression> value;
    
    ReturnStatement(std::unique_ptr<Expression> val = nullptr) : value(std::move(val)) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Expression statement
class ExpressionStatement : public Statement {
public:
    std::unique_ptr<Expression> expression;
    
    ExpressionStatement(std::unique_ptr<Expression> expr) : expression(std::move(expr)) {}
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Program (root node)
class Program : public ASTNode {
public:
    std::vector<std::unique_ptr<Statement>> statements;
    
    void accept(ASTVisitor& visitor) override;
    std::string toString() const override;
};

// Visitor pattern for AST traversal
class ASTVisitor {
public:
    virtual ~ASTVisitor() = default;
    
    virtual void visit(IntegerLiteral& node) = 0;
    virtual void visit(FloatLiteral& node) = 0;
    virtual void visit(StringLiteral& node) = 0;
    virtual void visit(BooleanLiteral& node) = 0;
    virtual void visit(Identifier& node) = 0;
    virtual void visit(BinaryOperation& node) = 0;
    virtual void visit(UnaryOperation& node) = 0;
    virtual void visit(FunctionCall& node) = 0;
    virtual void visit(ArrayAccess& node) = 0;
    virtual void visit(VariableDeclaration& node) = 0;
    virtual void visit(Assignment& node) = 0;
    virtual void visit(FunctionDeclaration& node) = 0;
    virtual void visit(IfStatement& node) = 0;
    virtual void visit(WhileLoop& node) = 0;
    virtual void visit(ForLoop& node) = 0;
    virtual void visit(ReturnStatement& node) = 0;
    virtual void visit(ExpressionStatement& node) = 0;
    virtual void visit(Program& node) = 0;
};

#endif // AST_H

