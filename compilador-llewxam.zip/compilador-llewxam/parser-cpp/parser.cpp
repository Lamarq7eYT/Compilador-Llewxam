#include "parser.h"
#include <iostream>

// Made By Llewxam - LlewLang Parser Implementation

Parser::Parser(const std::vector<Token>& tokens) : tokens(tokens), current(0) {}

Token& Parser::currentToken() {
    return tokens[current];
}

Token& Parser::peekToken() {
    if (current + 1 >= tokens.size()) {
        return tokens[tokens.size() - 1]; // Return EOF token
    }
    return tokens[current + 1];
}

bool Parser::isAtEnd() {
    return currentToken().type == TokenType::EOF_TOKEN;
}

void Parser::advance() {
    if (!isAtEnd()) {
        current++;
    }
}

bool Parser::match(TokenType type) {
    if (check(type)) {
        advance();
        return true;
    }
    return false;
}

bool Parser::check(TokenType type) {
    if (isAtEnd()) return false;
    return currentToken().type == type;
}

Token Parser::consume(TokenType type, const std::string& message) {
    if (check(type)) {
        Token token = currentToken();
        advance();
        return token;
    }
    
    throw ParseError(message + " at line " + std::to_string(currentToken().line));
}

std::unique_ptr<Program> Parser::parse() {
    return parseProgram();
}

std::unique_ptr<Program> Parser::parseProgram() {
    auto program = std::make_unique<Program>();
    
    while (!isAtEnd()) {
        try {
            auto stmt = parseStatement();
            if (stmt) {
                program->statements.push_back(std::move(stmt));
            }
        } catch (const ParseError& e) {
            std::cerr << "Parse error: " << e.what() << std::endl;
            // Skip to next statement
            while (!isAtEnd() && currentToken().type != TokenType::SEMICOLON) {
                advance();
            }
            if (currentToken().type == TokenType::SEMICOLON) {
                advance();
            }
        }
    }
    
    return program;
}

std::unique_ptr<Statement> Parser::parseStatement() {
    if (match(TokenType::LET) || match(TokenType::CONST)) {
        current--; // Go back to parse the keyword
        return parseVariableDeclaration();
    }
    
    if (match(TokenType::FUNC)) {
        current--; // Go back
        return parseFunctionDeclaration();
    }
    
    if (match(TokenType::IF)) {
        current--; // Go back
        return parseIfStatement();
    }
    
    if (match(TokenType::WHILE)) {
        current--; // Go back
        return parseWhileLoop();
    }
    
    if (match(TokenType::FOR)) {
        current--; // Go back
        return parseForLoop();
    }
    
    if (match(TokenType::RETURN)) {
        current--; // Go back
        return parseReturnStatement();
    }
    
    // Check for assignment
    if (check(TokenType::IDENTIFIER) && peekToken().type == TokenType::ASSIGN) {
        return parseAssignment();
    }
    
    return parseExpressionStatement();
}

std::unique_ptr<Statement> Parser::parseVariableDeclaration() {
    bool isConstant = match(TokenType::CONST);
    if (!isConstant) {
        consume(TokenType::LET, "Expected 'let' or 'const'");
    }
    
    Token name = consume(TokenType::IDENTIFIER, "Expected variable name");
    consume(TokenType::COLON, "Expected ':' after variable name");
    
    std::string type;
    if (match(TokenType::INT_TYPE)) type = "int";
    else if (match(TokenType::FLOAT_TYPE)) type = "float";
    else if (match(TokenType::STRING_TYPE)) type = "string";
    else if (match(TokenType::BOOL_TYPE)) type = "bool";
    else throw ParseError("Expected type annotation");
    
    auto varDecl = std::make_unique<VariableDeclaration>(name.value, type, isConstant);
    
    if (match(TokenType::ASSIGN)) {
        varDecl->initializer = parseExpression();
    }
    
    consume(TokenType::SEMICOLON, "Expected ';' after variable declaration");
    return std::move(varDecl);
}

std::unique_ptr<Statement> Parser::parseFunctionDeclaration() {
    consume(TokenType::FUNC, "Expected 'func'");
    Token name = consume(TokenType::IDENTIFIER, "Expected function name");
    
    consume(TokenType::LEFT_PAREN, "Expected '(' after function name");
    
    std::string returnType = "void";
    auto funcDecl = std::make_unique<FunctionDeclaration>(name.value, returnType);
    
    // Parse parameters
    if (!check(TokenType::RIGHT_PAREN)) {
        do {
            Token paramName = consume(TokenType::IDENTIFIER, "Expected parameter name");
            consume(TokenType::COLON, "Expected ':' after parameter name");
            
            std::string paramType;
            if (match(TokenType::INT_TYPE)) paramType = "int";
            else if (match(TokenType::FLOAT_TYPE)) paramType = "float";
            else if (match(TokenType::STRING_TYPE)) paramType = "string";
            else if (match(TokenType::BOOL_TYPE)) paramType = "bool";
            else throw ParseError("Expected parameter type");
            
            funcDecl->parameters.emplace_back(paramName.value, paramType);
        } while (match(TokenType::COMMA));
    }
    
    consume(TokenType::RIGHT_PAREN, "Expected ')' after parameters");
    
    // Parse return type
    if (match(TokenType::ARROW)) {
        if (match(TokenType::INT_TYPE)) funcDecl->returnType = "int";
        else if (match(TokenType::FLOAT_TYPE)) funcDecl->returnType = "float";
        else if (match(TokenType::STRING_TYPE)) funcDecl->returnType = "string";
        else if (match(TokenType::BOOL_TYPE)) funcDecl->returnType = "bool";
        else throw ParseError("Expected return type after '->'");
    }
    
    // Parse function body
    consume(TokenType::LEFT_BRACE, "Expected '{' before function body");
    funcDecl->body = parseBlock();
    
    return std::move(funcDecl);
}

std::unique_ptr<Statement> Parser::parseIfStatement() {
    consume(TokenType::IF, "Expected 'if'");
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'if'");
    
    auto condition = parseExpression();
    auto ifStmt = std::make_unique<IfStatement>(std::move(condition));
    
    consume(TokenType::RIGHT_PAREN, "Expected ')' after if condition");
    consume(TokenType::LEFT_BRACE, "Expected '{' after if condition");
    
    ifStmt->thenBranch = parseBlock();
    
    if (match(TokenType::ELSE)) {
        consume(TokenType::LEFT_BRACE, "Expected '{' after 'else'");
        ifStmt->elseBranch = parseBlock();
    }
    
    return std::move(ifStmt);
}

std::unique_ptr<Statement> Parser::parseWhileLoop() {
    consume(TokenType::WHILE, "Expected 'while'");
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'while'");
    
    auto condition = parseExpression();
    auto whileLoop = std::make_unique<WhileLoop>(std::move(condition));
    
    consume(TokenType::RIGHT_PAREN, "Expected ')' after while condition");
    consume(TokenType::LEFT_BRACE, "Expected '{' after while condition");
    
    whileLoop->body = parseBlock();
    
    return std::move(whileLoop);
}

std::unique_ptr<Statement> Parser::parseForLoop() {
    consume(TokenType::FOR, "Expected 'for'");
    Token variable = consume(TokenType::IDENTIFIER, "Expected loop variable");
    consume(TokenType::IN, "Expected 'in' after loop variable");
    
    auto start = parseExpression();
    consume(TokenType::RANGE, "Expected '..' in for loop range");
    auto end = parseExpression();
    
    auto forLoop = std::make_unique<ForLoop>(variable.value);
    forLoop->start = std::move(start);
    forLoop->end = std::move(end);
    
    consume(TokenType::LEFT_BRACE, "Expected '{' after for loop range");
    forLoop->body = parseBlock();
    
    return std::move(forLoop);
}

std::unique_ptr<Statement> Parser::parseReturnStatement() {
    consume(TokenType::RETURN, "Expected 'return'");
    
    std::unique_ptr<Expression> value = nullptr;
    if (!check(TokenType::SEMICOLON)) {
        value = parseExpression();
    }
    
    consume(TokenType::SEMICOLON, "Expected ';' after return statement");
    return std::make_unique<ReturnStatement>(std::move(value));
}

std::unique_ptr<Statement> Parser::parseAssignment() {
    Token name = consume(TokenType::IDENTIFIER, "Expected variable name");
    consume(TokenType::ASSIGN, "Expected '=' in assignment");
    
    auto value = parseExpression();
    consume(TokenType::SEMICOLON, "Expected ';' after assignment");
    
    return std::make_unique<Assignment>(name.value, std::move(value));
}

std::unique_ptr<Statement> Parser::parseExpressionStatement() {
    auto expr = parseExpression();
    consume(TokenType::SEMICOLON, "Expected ';' after expression");
    return std::make_unique<ExpressionStatement>(std::move(expr));
}

std::vector<std::unique_ptr<Statement>> Parser::parseBlock() {
    std::vector<std::unique_ptr<Statement>> statements;
    
    while (!check(TokenType::RIGHT_BRACE) && !isAtEnd()) {
        auto stmt = parseStatement();
        if (stmt) {
            statements.push_back(std::move(stmt));
        }
    }
    
    consume(TokenType::RIGHT_BRACE, "Expected '}' after block");
    return statements;
}

std::unique_ptr<Expression> Parser::parseExpression() {
    return parseLogicalOr();
}

std::unique_ptr<Expression> Parser::parseLogicalOr() {
    auto expr = parseLogicalAnd();
    
    while (match(TokenType::OR)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseLogicalAnd();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseLogicalAnd() {
    auto expr = parseEquality();
    
    while (match(TokenType::AND)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseEquality();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseEquality() {
    auto expr = parseComparison();
    
    while (match(TokenType::EQUAL) || match(TokenType::NOT_EQUAL)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseComparison();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseComparison() {
    auto expr = parseTerm();
    
    while (match(TokenType::GREATER_THAN) || match(TokenType::GREATER_EQUAL) ||
           match(TokenType::LESS_THAN) || match(TokenType::LESS_EQUAL)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseTerm();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseTerm() {
    auto expr = parseFactor();
    
    while (match(TokenType::PLUS) || match(TokenType::MINUS)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseFactor();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseFactor() {
    auto expr = parseUnary();
    
    while (match(TokenType::MULTIPLY) || match(TokenType::DIVIDE) || match(TokenType::MODULO)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseUnary();
        expr = std::make_unique<BinaryOperation>(std::move(expr), operator_, std::move(right));
    }
    
    return expr;
}

std::unique_ptr<Expression> Parser::parseUnary() {
    if (match(TokenType::NOT) || match(TokenType::MINUS)) {
        TokenType operator_ = tokens[current - 1].type;
        auto right = parseUnary();
        return std::make_unique<UnaryOperation>(operator_, std::move(right));
    }
    
    return parseCall();
}

std::unique_ptr<Expression> Parser::parseCall() {
    auto expr = parsePrimary();
    
    while (true) {
        if (match(TokenType::LEFT_PAREN)) {
            // Function call
            if (auto identifier = dynamic_cast<Identifier*>(expr.get())) {
                std::string name = identifier->name;
                expr.release(); // Release ownership
                expr = finishCall(name);
            } else {
                throw ParseError("Invalid function call");
            }
        } else if (match(TokenType::LEFT_BRACKET)) {
            // Array access
            auto index = parseExpression();
            consume(TokenType::RIGHT_BRACKET, "Expected ']' after array index");
            expr = std::make_unique<ArrayAccess>(std::move(expr), std::move(index));
        } else {
            break;
        }
    }
    
    return expr;
}

std::unique_ptr<FunctionCall> Parser::finishCall(const std::string& name) {
    auto call = std::make_unique<FunctionCall>(name);
    
    if (!check(TokenType::RIGHT_PAREN)) {
        do {
            call->arguments.push_back(parseExpression());
        } while (match(TokenType::COMMA));
    }
    
    consume(TokenType::RIGHT_PAREN, "Expected ')' after function arguments");
    return call;
}

std::unique_ptr<Expression> Parser::parsePrimary() {
    if (match(TokenType::TRUE)) {
        return std::make_unique<BooleanLiteral>(true);
    }
    
    if (match(TokenType::FALSE)) {
        return std::make_unique<BooleanLiteral>(false);
    }
    
    if (match(TokenType::INTEGER)) {
        int value = std::stoi(tokens[current - 1].value);
        return std::make_unique<IntegerLiteral>(value);
    }
    
    if (match(TokenType::FLOAT)) {
        double value = std::stod(tokens[current - 1].value);
        return std::make_unique<FloatLiteral>(value);
    }
    
    if (match(TokenType::STRING)) {
        return std::make_unique<StringLiteral>(tokens[current - 1].value);
    }
    
    if (match(TokenType::IDENTIFIER)) {
        return std::make_unique<Identifier>(tokens[current - 1].value);
    }
    
    if (match(TokenType::LEFT_PAREN)) {
        auto expr = parseExpression();
        consume(TokenType::RIGHT_PAREN, "Expected ')' after expression");
        return expr;
    }
    
    throw ParseError("Expected expression at line " + std::to_string(currentToken().line));
}

