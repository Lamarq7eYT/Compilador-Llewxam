#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"
#include "ast.h"
#include <vector>
#include <memory>

// Made By Llewxam - LlewLang Parser

class Parser {
private:
    std::vector<Token> tokens;
    size_t current;
    
    Token& currentToken();
    Token& peekToken();
    bool isAtEnd();
    void advance();
    bool match(TokenType type);
    bool check(TokenType type);
    Token consume(TokenType type, const std::string& message);
    
    // Parsing methods
    std::unique_ptr<Program> parseProgram();
    std::unique_ptr<Statement> parseStatement();
    std::unique_ptr<Statement> parseVariableDeclaration();
    std::unique_ptr<Statement> parseFunctionDeclaration();
    std::unique_ptr<Statement> parseIfStatement();
    std::unique_ptr<Statement> parseWhileLoop();
    std::unique_ptr<Statement> parseForLoop();
    std::unique_ptr<Statement> parseReturnStatement();
    std::unique_ptr<Statement> parseAssignment();
    std::unique_ptr<Statement> parseExpressionStatement();
    
    std::unique_ptr<Expression> parseExpression();
    std::unique_ptr<Expression> parseLogicalOr();
    std::unique_ptr<Expression> parseLogicalAnd();
    std::unique_ptr<Expression> parseEquality();
    std::unique_ptr<Expression> parseComparison();
    std::unique_ptr<Expression> parseTerm();
    std::unique_ptr<Expression> parseFactor();
    std::unique_ptr<Expression> parseUnary();
    std::unique_ptr<Expression> parseCall();
    std::unique_ptr<Expression> parsePrimary();
    
    std::unique_ptr<FunctionCall> finishCall(const std::string& name);
    std::vector<std::unique_ptr<Statement>> parseBlock();
    
public:
    Parser(const std::vector<Token>& tokens);
    std::unique_ptr<Program> parse();
    
    // Error handling
    class ParseError : public std::exception {
    private:
        std::string message;
    public:
        ParseError(const std::string& msg) : message(msg) {}
        const char* what() const noexcept override { return message.c_str(); }
    };
};

#endif // PARSER_H

