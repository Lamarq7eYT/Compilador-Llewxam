#include "lexer.h"
#include <iostream>
#include <cctype>

// Made By Llewxam - LlewLang Lexer Implementation

Lexer::Lexer(const std::string& source) 
    : source(source), position(0), line(1), column(1) {
    initKeywords();
}

void Lexer::initKeywords() {
    keywords = {
        {"let", TokenType::LET},
        {"const", TokenType::CONST},
        {"func", TokenType::FUNC},
        {"if", TokenType::IF},
        {"else", TokenType::ELSE},
        {"for", TokenType::FOR},
        {"while", TokenType::WHILE},
        {"return", TokenType::RETURN},
        {"struct", TokenType::STRUCT},
        {"in", TokenType::IN},
        {"true", TokenType::TRUE},
        {"false", TokenType::FALSE},
        {"int", TokenType::INT_TYPE},
        {"float", TokenType::FLOAT_TYPE},
        {"string", TokenType::STRING_TYPE},
        {"bool", TokenType::BOOL_TYPE}
    };
}

char Lexer::currentChar() {
    if (position >= source.length()) {
        return '\0';
    }
    return source[position];
}

char Lexer::peekChar() {
    if (position + 1 >= source.length()) {
        return '\0';
    }
    return source[position + 1];
}

void Lexer::advance() {
    if (position < source.length()) {
        if (source[position] == '\n') {
            line++;
            column = 1;
        } else {
            column++;
        }
        position++;
    }
}

void Lexer::skipWhitespace() {
    while (currentChar() != '\0' && std::isspace(currentChar()) && currentChar() != '\n') {
        advance();
    }
}

void Lexer::skipComment() {
    if (currentChar() == '/' && peekChar() == '/') {
        // Single line comment
        while (currentChar() != '\0' && currentChar() != '\n') {
            advance();
        }
    } else if (currentChar() == '/' && peekChar() == '*') {
        // Multi-line comment
        advance(); // skip '/'
        advance(); // skip '*'
        
        while (currentChar() != '\0') {
            if (currentChar() == '*' && peekChar() == '/') {
                advance(); // skip '*'
                advance(); // skip '/'
                break;
            }
            advance();
        }
    }
}

Token Lexer::readString() {
    int startLine = line;
    int startColumn = column;
    std::string value = "";
    
    advance(); // skip opening quote
    
    while (currentChar() != '\0' && currentChar() != '"') {
        if (currentChar() == '\\') {
            advance();
            switch (currentChar()) {
                case 'n': value += '\n'; break;
                case 't': value += '\t'; break;
                case 'r': value += '\r'; break;
                case '\\': value += '\\'; break;
                case '"': value += '"'; break;
                default: value += currentChar(); break;
            }
        } else {
            value += currentChar();
        }
        advance();
    }
    
    if (currentChar() == '"') {
        advance(); // skip closing quote
    }
    
    return Token(TokenType::STRING, value, startLine, startColumn);
}

Token Lexer::readNumber() {
    int startLine = line;
    int startColumn = column;
    std::string value = "";
    bool isFloat = false;
    
    while (currentChar() != '\0' && (std::isdigit(currentChar()) || currentChar() == '.')) {
        if (currentChar() == '.') {
            if (isFloat) break; // Second dot, stop
            isFloat = true;
        }
        value += currentChar();
        advance();
    }
    
    TokenType type = isFloat ? TokenType::FLOAT : TokenType::INTEGER;
    return Token(type, value, startLine, startColumn);
}

Token Lexer::readIdentifier() {
    int startLine = line;
    int startColumn = column;
    std::string value = "";
    
    while (currentChar() != '\0' && 
           (std::isalnum(currentChar()) || currentChar() == '_')) {
        value += currentChar();
        advance();
    }
    
    // Check if it's a keyword
    auto it = keywords.find(value);
    TokenType type = (it != keywords.end()) ? it->second : TokenType::IDENTIFIER;
    
    return Token(type, value, startLine, startColumn);
}

Token Lexer::nextToken() {
    while (currentChar() != '\0') {
        skipWhitespace();
        
        int currentLine = line;
        int currentColumn = column;
        char ch = currentChar();
        
        // Comments
        if (ch == '/' && (peekChar() == '/' || peekChar() == '*')) {
            skipComment();
            continue;
        }
        
        // Newlines
        if (ch == '\n') {
            advance();
            return Token(TokenType::NEWLINE, "\\n", currentLine, currentColumn);
        }
        
        // Strings
        if (ch == '"') {
            return readString();
        }
        
        // Numbers
        if (std::isdigit(ch)) {
            return readNumber();
        }
        
        // Identifiers and keywords
        if (std::isalpha(ch) || ch == '_') {
            return readIdentifier();
        }
        
        // Two-character operators
        if (ch == '=' && peekChar() == '=') {
            advance(); advance();
            return Token(TokenType::EQUAL, "==", currentLine, currentColumn);
        }
        if (ch == '!' && peekChar() == '=') {
            advance(); advance();
            return Token(TokenType::NOT_EQUAL, "!=", currentLine, currentColumn);
        }
        if (ch == '<' && peekChar() == '=') {
            advance(); advance();
            return Token(TokenType::LESS_EQUAL, "<=", currentLine, currentColumn);
        }
        if (ch == '>' && peekChar() == '=') {
            advance(); advance();
            return Token(TokenType::GREATER_EQUAL, ">=", currentLine, currentColumn);
        }
        if (ch == '&' && peekChar() == '&') {
            advance(); advance();
            return Token(TokenType::AND, "&&", currentLine, currentColumn);
        }
        if (ch == '|' && peekChar() == '|') {
            advance(); advance();
            return Token(TokenType::OR, "||", currentLine, currentColumn);
        }
        if (ch == '-' && peekChar() == '>') {
            advance(); advance();
            return Token(TokenType::ARROW, "->", currentLine, currentColumn);
        }
        if (ch == '.' && peekChar() == '.') {
            advance(); advance();
            return Token(TokenType::RANGE, "..", currentLine, currentColumn);
        }
        
        // Single-character tokens
        advance();
        switch (ch) {
            case '+': return Token(TokenType::PLUS, "+", currentLine, currentColumn);
            case '-': return Token(TokenType::MINUS, "-", currentLine, currentColumn);
            case '*': return Token(TokenType::MULTIPLY, "*", currentLine, currentColumn);
            case '/': return Token(TokenType::DIVIDE, "/", currentLine, currentColumn);
            case '%': return Token(TokenType::MODULO, "%", currentLine, currentColumn);
            case '=': return Token(TokenType::ASSIGN, "=", currentLine, currentColumn);
            case '<': return Token(TokenType::LESS_THAN, "<", currentLine, currentColumn);
            case '>': return Token(TokenType::GREATER_THAN, ">", currentLine, currentColumn);
            case '!': return Token(TokenType::NOT, "!", currentLine, currentColumn);
            case ';': return Token(TokenType::SEMICOLON, ";", currentLine, currentColumn);
            case ',': return Token(TokenType::COMMA, ",", currentLine, currentColumn);
            case '.': return Token(TokenType::DOT, ".", currentLine, currentColumn);
            case ':': return Token(TokenType::COLON, ":", currentLine, currentColumn);
            case '(': return Token(TokenType::LEFT_PAREN, "(", currentLine, currentColumn);
            case ')': return Token(TokenType::RIGHT_PAREN, ")", currentLine, currentColumn);
            case '{': return Token(TokenType::LEFT_BRACE, "{", currentLine, currentColumn);
            case '}': return Token(TokenType::RIGHT_BRACE, "}", currentLine, currentColumn);
            case '[': return Token(TokenType::LEFT_BRACKET, "[", currentLine, currentColumn);
            case ']': return Token(TokenType::RIGHT_BRACKET, "]", currentLine, currentColumn);
            default:
                return Token(TokenType::INVALID, std::string(1, ch), currentLine, currentColumn);
        }
    }
    
    return Token(TokenType::EOF_TOKEN, "", line, column);
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;
    Token token = nextToken();
    
    while (token.type != TokenType::EOF_TOKEN) {
        if (token.type != TokenType::NEWLINE) { // Skip newlines for now
            tokens.push_back(token);
        }
        token = nextToken();
    }
    
    tokens.push_back(token); // Add EOF token
    return tokens;
}

std::string Lexer::tokenTypeToString(TokenType type) {
    switch (type) {
        case TokenType::INTEGER: return "INTEGER";
        case TokenType::FLOAT: return "FLOAT";
        case TokenType::STRING: return "STRING";
        case TokenType::BOOLEAN: return "BOOLEAN";
        case TokenType::IDENTIFIER: return "IDENTIFIER";
        case TokenType::LET: return "LET";
        case TokenType::CONST: return "CONST";
        case TokenType::FUNC: return "FUNC";
        case TokenType::IF: return "IF";
        case TokenType::ELSE: return "ELSE";
        case TokenType::FOR: return "FOR";
        case TokenType::WHILE: return "WHILE";
        case TokenType::RETURN: return "RETURN";
        case TokenType::STRUCT: return "STRUCT";
        case TokenType::IN: return "IN";
        case TokenType::TRUE: return "TRUE";
        case TokenType::FALSE: return "FALSE";
        case TokenType::INT_TYPE: return "INT_TYPE";
        case TokenType::FLOAT_TYPE: return "FLOAT_TYPE";
        case TokenType::STRING_TYPE: return "STRING_TYPE";
        case TokenType::BOOL_TYPE: return "BOOL_TYPE";
        case TokenType::PLUS: return "PLUS";
        case TokenType::MINUS: return "MINUS";
        case TokenType::MULTIPLY: return "MULTIPLY";
        case TokenType::DIVIDE: return "DIVIDE";
        case TokenType::MODULO: return "MODULO";
        case TokenType::ASSIGN: return "ASSIGN";
        case TokenType::EQUAL: return "EQUAL";
        case TokenType::NOT_EQUAL: return "NOT_EQUAL";
        case TokenType::LESS_THAN: return "LESS_THAN";
        case TokenType::GREATER_THAN: return "GREATER_THAN";
        case TokenType::LESS_EQUAL: return "LESS_EQUAL";
        case TokenType::GREATER_EQUAL: return "GREATER_EQUAL";
        case TokenType::AND: return "AND";
        case TokenType::OR: return "OR";
        case TokenType::NOT: return "NOT";
        case TokenType::SEMICOLON: return "SEMICOLON";
        case TokenType::COMMA: return "COMMA";
        case TokenType::DOT: return "DOT";
        case TokenType::COLON: return "COLON";
        case TokenType::ARROW: return "ARROW";
        case TokenType::RANGE: return "RANGE";
        case TokenType::LEFT_PAREN: return "LEFT_PAREN";
        case TokenType::RIGHT_PAREN: return "RIGHT_PAREN";
        case TokenType::LEFT_BRACE: return "LEFT_BRACE";
        case TokenType::RIGHT_BRACE: return "RIGHT_BRACE";
        case TokenType::LEFT_BRACKET: return "LEFT_BRACKET";
        case TokenType::RIGHT_BRACKET: return "RIGHT_BRACKET";
        case TokenType::NEWLINE: return "NEWLINE";
        case TokenType::EOF_TOKEN: return "EOF";
        case TokenType::INVALID: return "INVALID";
        default: return "UNKNOWN";
    }
}

