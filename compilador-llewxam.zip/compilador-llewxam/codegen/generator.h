#ifndef GENERATOR_H
#define GENERATOR_H

#include "../parser-cpp/ast.h"
#include <sstream>
#include <unordered_map>
#include <vector>

// Made By Llewxam - LlewLang Code Generator

class CodeGenerator : public ASTVisitor {
private:
    std::stringstream output;
    std::unordered_map<std::string, int> variables; // Variable name -> stack offset
    std::unordered_map<std::string, std::string> functions; // Function name -> label
    int stackOffset;
    int labelCounter;
    std::string currentFunction;
    
    // Helper methods
    std::string newLabel();
    void emitLabel(const std::string& label);
    void emit(const std::string& instruction);
    void emitComment(const std::string& comment);
    void pushValue();
    void popValue(const std::string& reg = "rax");
    
    // Built-in functions
    void generateBuiltins();
    void generatePrintFunction();
    void generateInputFunction();
    
public:
    CodeGenerator();
    
    // Visitor methods
    void visit(IntegerLiteral& node) override;
    void visit(FloatLiteral& node) override;
    void visit(StringLiteral& node) override;
    void visit(BooleanLiteral& node) override;
    void visit(Identifier& node) override;
    void visit(BinaryOperation& node) override;
    void visit(UnaryOperation& node) override;
    void visit(FunctionCall& node) override;
    void visit(ArrayAccess& node) override;
    void visit(VariableDeclaration& node) override;
    void visit(Assignment& node) override;
    void visit(FunctionDeclaration& node) override;
    void visit(IfStatement& node) override;
    void visit(WhileLoop& node) override;
    void visit(ForLoop& node) override;
    void visit(ReturnStatement& node) override;
    void visit(ExpressionStatement& node) override;
    void visit(Program& node) override;
    
    // Generate assembly code
    std::string generate(Program& program);
    
    // Save to file
    void saveToFile(const std::string& filename, const std::string& code);
};

#endif // GENERATOR_H

