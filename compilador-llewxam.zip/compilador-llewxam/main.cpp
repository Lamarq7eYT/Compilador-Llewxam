#include <iostream>
#include <fstream>
#include <string>
#include "parser-cpp/lexer.h"
#include "parser-cpp/parser.h"
#include "codegen/generator.h"

// Made By Llewxam - LlewLang Compiler Main

void printUsage(const std::string& programName) {
    std::cout << "LlewLang Compiler - Made By Llewxam\n";
    std::cout << "Usage: " << programName << " <input_file> [output_file]\n";
    std::cout << "\n";
    std::cout << "Examples:\n";
    std::cout << "  " << programName << " hello.llew\n";
    std::cout << "  " << programName << " fibonacci.llew output.asm\n";
    std::cout << "\n";
    std::cout << "Llewxam passou por aqui! 🚀\n";
}

std::string readFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }
    
    std::string content;
    std::string line;
    while (std::getline(file, line)) {
        content += line + "\n";
    }
    
    return content;
}

int main(int argc, char* argv[]) {
    std::cout << "🔧 LlewLang Compiler - Made By Llewxam\n";
    std::cout << "======================================\n\n";
    
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }
    
    std::string inputFile = argv[1];
    std::string outputFile = (argc > 2) ? argv[2] : "output.asm";
    
    try {
        std::cout << "📝 Reading source file: " << inputFile << "\n";
        std::string sourceCode = readFile(inputFile);
        
        std::cout << "🔍 Lexical analysis...\n";
        Lexer lexer(sourceCode);
        auto tokens = lexer.tokenize();
        
        std::cout << "   Found " << tokens.size() << " tokens\n";
        
        std::cout << "🌳 Syntactic analysis...\n";
        Parser parser(tokens);
        auto program = parser.parse();
        
        std::cout << "   AST constructed successfully\n";
        
        std::cout << "⚙️  Code generation...\n";
        CodeGenerator generator;
        std::string assemblyCode = generator.generate(*program);
        
        std::cout << "💾 Saving assembly to: " << outputFile << "\n";
        generator.saveToFile(outputFile, assemblyCode);
        
        std::cout << "\n✅ Compilation successful!\n";
        std::cout << "📊 Statistics:\n";
        std::cout << "   - Input file: " << inputFile << "\n";
        std::cout << "   - Output file: " << outputFile << "\n";
        std::cout << "   - Tokens processed: " << tokens.size() << "\n";
        std::cout << "   - Assembly lines: " << std::count(assemblyCode.begin(), assemblyCode.end(), '\n') << "\n";
        
        std::cout << "\n🎯 Llewxam passou por aqui!\n";
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "❌ Error: " << e.what() << "\n";
        return 1;
    }
}

