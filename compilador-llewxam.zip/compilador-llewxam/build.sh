#!/bin/bash

# Build Script - LlewLang Compiler
# Made By Llewxam

echo "🔧 Building LlewLang Compiler - Made By Llewxam"
echo "=============================================="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Verificar dependências
echo -e "${BLUE}🔍 Checking dependencies...${NC}"

if ! command -v g++ &> /dev/null; then
    echo -e "${RED}❌ g++ not found. Please install g++${NC}"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 not found. Please install Python3${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All dependencies found${NC}"

# Instalar dependências Python
echo -e "${BLUE}📦 Installing Python dependencies...${NC}"
pip3 install rich > /dev/null 2>&1 || {
    echo -e "${YELLOW}⚠️  Could not install rich. CLI will have limited features.${NC}"
}

# Compilar o compilador C++
echo -e "${BLUE}🔨 Compiling LlewLang compiler...${NC}"

g++ -std=c++17 -O2 -Wall -Wextra \
    parser-cpp/lexer.cpp \
    parser-cpp/ast.cpp \
    parser-cpp/parser.cpp \
    codegen/generator.cpp \
    main.cpp \
    -o llewlang-compiler

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Compiler built successfully!${NC}"
else
    echo -e "${RED}❌ Compilation failed${NC}"
    exit 1
fi

# Tornar CLI executável
chmod +x cli-python/llewc.py

# Criar link simbólico para facilitar uso
if [ ! -f "llewc" ]; then
    ln -s cli-python/llewc.py llewc
    echo -e "${GREEN}✅ Created llewc symlink${NC}"
fi

# Testar compilação com exemplo
echo -e "${BLUE}🧪 Testing with hello.llew...${NC}"

if [ -f "examples/hello.llew" ]; then
    ./llewlang-compiler examples/hello.llew test_output.asm
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Test compilation successful!${NC}"
        rm -f test_output.asm
    else
        echo -e "${YELLOW}⚠️  Test compilation had issues${NC}"
    fi
fi

echo ""
echo -e "${GREEN}🎉 Build completed successfully!${NC}"
echo -e "${GREEN}Made By Llewxam${NC}"
echo ""
echo "📋 Available commands:"
echo -e "   ${BLUE}./llewlang-compiler <file.llew>${NC}     # Direct compiler"
echo -e "   ${BLUE}./llewc compile <file.llew>${NC}         # CLI compile"
echo -e "   ${BLUE}./llewc run <file.llew>${NC}             # CLI run"
echo -e "   ${BLUE}./llewc examples${NC}                    # List examples"
echo ""
echo "📁 Example files:"
echo "   examples/hello.llew"
echo "   examples/fibonacci.llew"
echo "   examples/variables.llew"
echo ""
echo -e "${YELLOW}Llewxam passou por aqui! 🎯${NC}"

